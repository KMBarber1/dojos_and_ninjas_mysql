from flask_app import app
from flask import redirect, render_template,request
from flask_app.models.dojo import Dojo


@app.route("/")
def index():
    # call the get all classmethod to get all friends
    list_of_dojos = Dojo.get_all()
    print(list_of_dojos)

    return render_template("dojos.html", all_dojos = list_of_dojos)

@app.route("dojo/new")
def new_dojo():
    return render_template("new_ninja.html")

@app.route("/dojos/create", methods = ["POST"])
def create_user():
    Dojo.create(request.form)

    return redirect("/")

@app.route("/dojos/<int:user_id>/show")
def show_dojo(dojo_id):
    return render_template("dojo_show.html", this_dojo = Dojo.get_one({"id": dojo_id}))

@app.route("/dojos/<int:dojo_id>/edit")
def edit_dojo(dojo_id):
    return render_template("new_ninja.html", this_dojo = Dojo.get_one({"id": dojo_id}))

# @app.route("/users/<int:user_id>/info")
# def info_user(user_id):
#     return render_template("info_user.html", this_user = User.get_one({"id": user_id}))

@app.route("/dojos/<int:dojo_id>/update", methods = ["POST"])
def update_dojo(dojo_id):
    updated_data = {
        **request.form,
        "id": dojo_id
    }
    Dojo.update(updated_data)

    return redirect("/")

@app.route("/dojos/<int:dojo_id>/delete")
def delete_dojo(dojo_id):
    Dojo.delete({"id":dojo_id})

    return redirect("/")




