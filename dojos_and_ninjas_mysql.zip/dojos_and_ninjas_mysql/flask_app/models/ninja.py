from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import dojo


class Ninjas:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    

    @classmethod
    def create(cls, data):
        query= "INSERT INTO dojos (first_name, last_name, email, created_at, updated_at) VALUES (%(first_name)s, %(last_name)s, %(email)s, NOW(), NOW());"
        result = connectToMySQL("dojos_and_ninjas").query_db(query, data) 

        return result